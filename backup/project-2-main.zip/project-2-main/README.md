# project-2

## Articles
Graphing using mongobd
https://towardsdatascience.com/graphing-data-from-mongodb-99c3722650da

## 
https://stackoverflow.com/questions/49153020/how-to-dump-a-collection-to-json-file-using-pymongo


# Files
## Graph #1
# plots.js and plot1.html
Currently filtered to just show 2021. Add a drop-down selector?

# plot2.js and plot2.html
Shows 5 years of data across the boxplot. Years are hardcoded - could probably be done with a for loop

# Jupyter files
## MongoDB Upload
initial attempt to upload data to Mongo. Each column is an array, which was hard to use

## MongoDB Upload 2




